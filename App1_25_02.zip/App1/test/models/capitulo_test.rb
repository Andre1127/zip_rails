require "test_helper"

class CapituloTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
